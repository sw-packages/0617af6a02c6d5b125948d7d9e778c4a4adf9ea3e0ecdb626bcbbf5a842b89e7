#ifndef __al_included_allegro5_aintern_osxclipboard_h
#define __al_included_allegro5_aintern_osxclipboard_h


#include "allegro5/internal/aintern_display.h"


#ifdef __cplusplus
extern "C" {
#endif

void _al_osx_add_clipboard_functions(ALLEGRO_DISPLAY_INTERFACE *vt);

#ifdef __cplusplus
}
#endif


#endif

/* vim: set sts=3 sw=3 et: */
